Thaumcraft 4
============

Thaumcraft localization files

Add any localization files here to add language support for Thaumcraft 4

Always use the en_US.lang file as the origin of your entries, this is the most up-to-date file!

Keep in mind these files HAVE to be UTF-8 without BOM encoded, anything else will NOT work!
